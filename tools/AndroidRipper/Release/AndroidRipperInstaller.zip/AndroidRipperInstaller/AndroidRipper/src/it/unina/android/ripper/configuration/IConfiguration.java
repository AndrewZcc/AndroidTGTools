package it.unina.android.ripper.configuration;

/**
 * Configuration Interface
 * 
 * @author Nicola Amatucci - REvERSE
 *
 */
public interface IConfiguration {

}
